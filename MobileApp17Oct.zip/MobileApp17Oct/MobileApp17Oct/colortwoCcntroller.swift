//
//  colortwoCcntroller.swift
//  MobileApp17Oct
//
//  Created by Student on 10/17/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

import UIKit

class colortwoCcntroller: NSObject {
   
}
