//
//  ViewController.swift
//  Exam1_55011212153
//
//  Created by Student on 10/10/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var inputName: UITextField!
    
    @IBOutlet weak var inputVolume: UITextField!
    
    @IBOutlet weak var inputPrice: UITextField!
    
    @IBOutlet weak var result: UITextField!
    
    @IBOutlet weak var show1: UITextField!
    
    @IBOutlet weak var show2: UITextField!
    
    @IBOutlet weak var show3: UITextField!
    
    @IBAction func total(sender: UIButton) {
        var volume : NSString = inputVolume.text
        var price : NSString = inputPrice.text
        var p1 : Double = volume.doubleValue
        var p2 : Double = price.doubleValue
        
        var z = p1 * p2
        var str = NSString(format: "%.0f", z)
        
        result.text = str + " Baht"
    }
    
    @IBAction func profit(sender: UIButton) {
        var volume : NSString = inputVolume.text
        var price : NSString = inputPrice.text
        var p1 : Double = volume.doubleValue
        var p2 : Double = price.doubleValue
        
        var up3 = p1 * ( p2 * 3 / 100)
        var up5 = p1 * ( p2 * 5 / 100)
        var up10 = p1 * ( p2 * 10 / 100)
        
        var str1 = NSString(format: "%.2f", up3)
        var str2 = NSString(format: "%.2f", up5)
        var str3 = NSString(format: "%.2f", up10)
        
        show1.text = "ราคาหุ้นขึ้น3% : กำไร \(str1) บาท"
        show2.text = "ราคาหุ้นขึ้น5% : กำไร \(str2) บาท"
        show3.text = "ราคาหุ้นขึ้น10% : กำไร \(str3) บาท"
        
    }
    
    
    @IBAction func clear(sender: UIButton) {
        inputName.text = nil
        inputVolume.text = nil
        inputPrice.text = nil
        result.text = nil
        show1.text = nil
        show2.text = nil
        show3.text = nil
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

